import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
public class driver {
    public static void main(String[] args) {
        //create an ArrayList of type Shapes and populate it with Rectangle and Circle instances
        ArrayList<Shapes> shapes = new ArrayList<Shapes>();
        shapes.add(new Circle(5));
        shapes.add(new Rectangle(5, 10));
        shapes.add(new Circle(10));
        shapes.add(new Rectangle(10, 20));
        shapes.add(new Circle(15));
        shapes.add(new Rectangle(15, 30));
        shapes.add(new Circle(20));
        shapes.add(new Rectangle(20, 40));
        shapes.add(new Circle(25));
        shapes.add(new Rectangle(25, 50));



        // implement public static Shapes largestShape(List<Shapes> list) method
        // that returns the largest shape in the list



        //calculate the largest shape based on area in the array

        /*double largest = 0;
        for (Shapes s : shapes) {
            s.calculateArea();
            if (s.getArea() > largest) {
                largest = s.getArea();
            }
        }*/







    }
    //function1
    public static Shapes largestShape(List<Shapes> list) {
        Shapes largest = list.get(0);
        for (int i = 1; i < list.size(); i++) {
            if (list.get(i).getArea() > largest.getArea()) {
                largest = list.get(i);
            }
        }
        return largest;
    }




}
