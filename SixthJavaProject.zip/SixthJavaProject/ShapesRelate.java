interface ShapesRelate {
    int compareShapes(int ShapesRelate);

}





