public class Rectangle extends Shapes implements ShapesRelate {
    private double length;
    private double width;

    public Rectangle(){
        super();
    }
    public Rectangle(double length, double width) {
        this.length = length;
        this.width = width;
    }
    // setWidth type double: void
    public void setWidth(double width) {
        this.width = width;
    }
    // getWidth() type double
    public double getWidth() {
        return width;
    }
    // setLength type double: void
    public void setLength(double length) {
        this.length = length;
    }
    // getLength() type double return length
    public double getLength() {
        return length;
    }
    //toString() type String length + width
    public String toString() {
        return "Rectangle [length=" + length + ", width=" + width + "]";
    }
    //calculate area of rectangle
    public void calculateArea() {
        area = length * width;
    }

    @Override
    public int compareShapes(int ShapesRelate) {
        return 0;
    }
}
