public class Circle extends Shapes implements ShapesRelate {
    private double radius;
    private double area;
    //circle constructor
    public Circle(){
        super();
    }
    // Circle constructor double radius
    public Circle(double radius) {
        this.radius = radius;
    }
    //getRadius() type double
    public double getRadius() {
        return radius;
    }
    //setRadius type double: void
    public void setRadius(double radius) {
        this.radius = radius;
    }

    //calculateArea() type void
    public void calculateArea() {
        area = Math.PI * radius * radius;
    }

    //toString() type String
    public String toString() {
        return "Circle [radius=" + radius + ", area=" + area + "]";
    }

    @Override
    public int compareShapes(int ShapesRelate) {
        return 0;
    }
}
