//create an ArrayList of type Shapes and populate it with Rectangle and Circle instances
 public abstract class Shapes implements ShapesRelate {
    protected double area;

    public Shapes(){

    }

    public double getArea() {
        return area;
    }

    public abstract void calculateArea();

    //compare area of shapes
    public int compareShapes(Shapes ShapesRelate){
        return Double.compare(this.area, ShapesRelate.area);
    }




}




