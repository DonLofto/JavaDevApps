
import java.util.ArrayList;

public class Library {

    public Library(String name) {

    }

    public String getName() {
        return name;
        }


    public <ArrayList> arraylist getBooks() {
        ArrayList books = new ArrayList<Book>();
        return books;

    }

    public void addBook(Book book) {
        return book;
    }

    public void removeBook(Book book) {
        books.remove(book);
    }

    public String toString() {
        return "Library [name=" + name + "]";
    }



}
